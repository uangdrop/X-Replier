const AUTH_API = "http://213.199.34.158:3000/api/check-auth";
const GENERATE_API = "http://213.199.34.158:3000/api/generate-reply";

let isProcessing = false;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "GENERATE_REPLY") {
    if (isProcessing) {
      sendResponse({ reply: "" });
      return true;
    }
    isProcessing = true; 
    
    checkLicenseAndGenerate(request.text, request.lang, (response) => {
      sendResponse(response);
      setTimeout(() => { isProcessing = false; }, 1000);
    });
    
    return true; 
  }
});

async function checkLicenseAndGenerate(tweetText, lang, sendResponse) {
  chrome.storage.local.get(['myUUID', 'isActivated', 'lastChecked'], async (data) => {
    const uuid = data.myUUID;
    const isActivated = data.isActivated;
    const lastChecked = data.lastChecked || 0;
    const OneDayInMs = 24 * 60 * 60 * 1000;

    if (!uuid || !isActivated) {
      sendResponse({ reply: "⚠️ AKSES DITOLAK: Device belum diaktivasi! Silakan buka pop-up ekstensi untuk mendaftarkan UUID Anda." });
      return;
    }

    if (Date.now() - lastChecked > OneDayInMs) {
      try {
        const res = await fetch(AUTH_API, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ uuid: uuid })
        });
        const result = await res.json();
        
        if (!result.success) {
          chrome.storage.local.set({ 
            isActivated: false,
            lastChecked: 0 
          });
          
          sendResponse({ reply: "⚠️ AKSES DIPUTUS: Validasi harian gagal. Syarat grup/nama melanggar! Silakan penuhi syarat kembali dan masukkan UUID/Cek Status lagi di pop-up." });
          return;
        }
        

        chrome.storage.local.set({ lastChecked: Date.now() });
      } catch (err) {

      }
    }


    try {
      const response = await fetch(GENERATE_API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          uuid: uuid,
          tweetText: tweetText,
          detectedLang: lang
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        sendResponse({ reply: errorData.error || "⚠️ Akses ditolak oleh server pusat." });
        return;
      }

      const dataJson = await response.json();
      let replyText = dataJson.choices[0].message.content;
      replyText = replyText.replace(/^["']|["']$/g, '');

      sendResponse({ reply: replyText.trim() });
    } catch (error) {
      console.error("Error VPS Secure API:", error);
      sendResponse({ error: "⚠️ Gagal memproses AI. Server Auth sibuk atau token tidak valid." });
    }
  });
}