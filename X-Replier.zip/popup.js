const AUTH_API = "http://213.199.34.158:3000/api/check-auth";

function generateUUID() {
  return 'kh-dev-' + Math.random().toString(36).substring(2, 11) + Math.random().toString(36).substring(2, 11);
}

document.addEventListener('DOMContentLoaded', () => {
  const uuidDisplay = document.getElementById('uuidDisplay');
  const btnCheck = document.getElementById('btnCheck');
  const statusArea = document.getElementById('statusArea');


  chrome.storage.local.get(['myUUID', 'isActivated'], (data) => {
    let uuid = data.myUUID;
    if (!uuid) {
      uuid = generateUUID();
      chrome.storage.local.set({ myUUID: uuid });
    }
    
    if (uuidDisplay) {
      uuidDisplay.innerText = uuid;
    }

    if (data.isActivated && statusArea) {
      statusArea.innerText = "✅ Ekstensi Aktif & Terverifikasi!";
      statusArea.style.color = "#00ba7c";
    }
  });


  if (btnCheck) {
    btnCheck.addEventListener('click', () => {
      chrome.storage.local.get(['myUUID'], (data) => {
        const uuid = data.myUUID;
        
        if (!statusArea) return;
        statusArea.innerText = "⏳ Memeriksa basis data...";
        statusArea.style.color = "#ffd43b";

        fetch(AUTH_API, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ uuid: uuid })
        })
        .then(res => res.json())
        .then(result => {
          if (result.success) {
            statusArea.innerText = "✅ Sukses! Device Anda resmi dikunci.";
            statusArea.style.color = "#00ba7c";
            chrome.storage.local.set({ isActivated: true, lastChecked: Date.now() });
          } else {
            statusArea.innerText = "❌ Gagal! UUID belum terdaftar atau syarat tidak sesuai.";
            statusArea.style.color = "#f4212e";
            chrome.storage.local.set({ isActivated: false });
          }
        })
        .catch(err => {
          statusArea.innerText = "⚠️ Server Auth Offline atau Port Terblokir.";
          statusArea.style.color = "#f4212e";
        });
      });
    });
  }
});