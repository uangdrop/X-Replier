let isGenerating = false;


function getTweetText(clickedButton) {

  const cellInnerDiv = clickedButton.closest('div[data-testid="cellInnerDiv"]');
  if (cellInnerDiv) {

    const siblingTweet = cellInnerDiv.previousElementSibling?.querySelector('div[data-testid="tweetText"]');
    if (siblingTweet) return siblingTweet.innerText;
  }


  const mainArticle = clickedButton.closest('article[data-testid="tweet"]');
  if (mainArticle) {
    const mainText = mainArticle.querySelector('div[data-testid="tweetText"]');
    if (mainText) return mainText.innerText;
  }


  const firstTweet = document.querySelector('article[data-testid="tweet"] div[data-testid="tweetText"]');
  return firstTweet ? firstTweet.innerText : null;
}


function injectAIButton() {
  if (isGenerating) return;

  const toolbars = document.querySelectorAll('div[data-testid="toolBar"]');
  
  toolbars.forEach(toolbar => {
    if (toolbar.querySelector('.btn-local-ai')) return; 

    const aiButton = document.createElement('button');
    aiButton.className = "btn-local-ai";
    aiButton.innerText = "☕️AI Reply";
    aiButton.style = "background: #1d9bf0; color: white; border: none; padding: 6px 12px; border-radius: 9999px; font-weight: bold; cursor: pointer; margin-left: 10px; display: inline-block; z-index: 9999;";

    aiButton.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();

      if (isGenerating) return;


      const contextTweet = getTweetText(aiButton);
      

      console.log("TEKS TWEET YANG TERBACA OLEH EKSTENSI:", contextTweet);

      if (!contextTweet) {
        alert("Gagal membaca teks tweet asli.");
        return;
      }

      isGenerating = true;
      aiButton.innerText = "Generating...";
      aiButton.disabled = true;

      chrome.runtime.sendMessage({ type: "GENERATE_REPLY", text: contextTweet }, (response) => {
        aiButton.innerText = "✨ AI Reply";
        aiButton.disabled = false;

        if (response && response.reply) {
          insertReplyToX(response.reply);
        } else {
          alert("Gagal: " + (response.error || "Unknown error"));
        }
        
        setTimeout(() => { isGenerating = false; }, 1000);
      });
    });

    toolbar.appendChild(aiButton);
  });
}


function insertReplyToX(text) {
  const replyBox = document.querySelector('div[data-testid="tweetTextarea_0"]');
  if (!replyBox) {
    alert("Kolom balasan tidak ditemukan.");
    isGenerating = false;
    return;
  }

  replyBox.focus();

  let textSpan = replyBox.querySelector('span[data-text="true"]');
  
  if (!textSpan) {
    const innerDiv = replyBox.querySelector('div[data-contents="true"] div[data-block="true"] div');
    if (innerDiv) {
      innerDiv.innerHTML = `<span data-text="true">${text}</span>`;
      textSpan = innerDiv.querySelector('span[data-text="true"]');
    }
  } else {
    textSpan.innerText = text;
  }

  const inputEvent = new Event('input', { bubbles: true, cancelable: true });
  replyBox.dispatchEvent(inputEvent);
}


setInterval(injectAIButton, 2000);